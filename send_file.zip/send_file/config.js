const mongoose = require("mongoose");

mongoose.connect(
  "mongodb+srv://meddaily:N5ND46K4d-R$tHe@cluster0.r8ssiei.mongodb.net/?retryWrites=true&w=majority"
);

// PORT=8000
// # MONGO_CONNECTION=mongodb://localhost:27017/med_db
// MONGO_CONNECTION=mongodb+srv://meddaily:N5ND46K4d-R$tHe@cluster0.r8ssiei.mongodb.net/?retryWrites=true&w=majority
// ACCESS_TOKEN_SECRET=6ae1330f6e9656dd6bb6d4ba1179259d875443ca4daf816517c4300bd807aaaf6b4d3aad2e1da455370feab69c9d151a2a4667372ab0dfaa9c28642dec6a4746
// AWS_ID=AKIAWMM3KPYLBZAL2EUO
// AWS_SECRET=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
// AWS_BUCKET_NAME=meddaily-images